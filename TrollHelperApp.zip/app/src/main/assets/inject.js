(function(){
  const API_BASE = "https://aktrollanaliz.com/api";
  const LIST_URL = API_BASE + "/l.php";
  const ADD_URL  = API_BASE + "/add_user.php?eksi_user_id="; // adjust to your API
  const BTN_CLASS = "th-add-btn";
  const MARK_CLASS = "th-marked";

  function once(id){
    if(document.getElementById(id)) return false;
    const m = document.createElement("div");
    m.id = id;
    m.style.cssText = "position:fixed;top:10px;left:50%;transform:translateX(-50%);font:600 12px sans-serif;background:#212529;color:#fff;padding:6px 10px;border-radius:8px;z-index:999999";
    m.textContent = "TrollHelper aktif";
    document.body.appendChild(m);
    setTimeout(()=>m.remove(),2000);
    return true;
  }

  async function fetchList(){
    try{
      const r = await fetch(LIST_URL, {credentials:"include"});
      const data = await r.json();
      const ids = new Set(data.map(x=>x.id));
      const names = new Set(data.map(x=>x.username?.toLowerCase()).filter(Boolean));
      return {ids, names};
    }catch(e){ console.warn("List fetch fail", e); return {ids:new Set(), names:new Set()}; }
  }

  function findAuthorInfo(entryEl){
    // Try data-author-id
    const container = entryEl.closest("[data-author-id]") || entryEl;
    const id = container.getAttribute("data-author-id");
    // Try by author link
    let name = null;
    const a = entryEl.querySelector('a[rel="author"], a[class*="author"], a[href*="/biri/"]');
    if(a) name = (a.textContent || "").trim().toLowerCase();
    return {id, name};
  }

  function addButton(entryEl, state){
    if(entryEl.querySelector("."+BTN_CLASS)) return;
    const btn = document.createElement("button");
    btn.className = BTN_CLASS;
    btn.textContent = state === "marked" ? "✅ Troll" : "🚨 Troll Ekle";
    btn.style.cssText = "margin-top:6px;padding:6px 10px;border-radius:8px;border:0;background:"+(state==="marked"?"#198754":"#dc3545")+";color:#fff;font-weight:700;cursor:pointer;";
    btn.onclick = async function(e){
      e.stopPropagation();
      const {id,name} = findAuthorInfo(entryEl);
      const target = id || name;
      if(!target){ alert("Yazar bilgisi bulunamadı"); return; }
      try{
        await fetch(ADD_URL + encodeURIComponent(target), {method:"POST", credentials:"include"});
        btn.textContent = "✅ Troll";
        btn.style.background = "#198754";
        entryEl.classList.add(MARK_CLASS);
      }catch(err){
        alert("Kayıt başarısız");
      }
    };
    // Place after actions if exist, else at end
    const actions = entryEl.querySelector('[class*="entry-footer"], [class*="entry-actions"]');
    (actions || entryEl).appendChild(btn);
  }

  function process(entries, list){
    entries.forEach(el=>{
      const {id,name} = findAuthorInfo(el);
      const isMarked = (id && list.ids.has(Number(id))) || (name && list.names.has(name));
      addButton(el, isMarked ? "marked" : "new");
      if(isMarked) el.classList.add(MARK_CLASS);
    });
  }

  async function init(){
    once("th-badge");
    const list = await fetchList();
    const entries = Array.from(document.querySelectorAll('[class*="content"], article, .content'));
    process(entries.map(e => e.closest("li, article, .entry, .content") || e), list);

    // Re-run on DOM changes
    const obs = new MutationObserver(()=>{
      const ens = Array.from(document.querySelectorAll('[class*="content"], article, .content'));
      process(ens.map(e => e.closest("li, article, .entry, .content") || e), list);
    });
    obs.observe(document.body, {childList:true, subtree:true});
  }

  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", init); }
  else { init(); }
})();